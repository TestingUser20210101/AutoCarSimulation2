using static MaltemTest.Program;

namespace AutoDrivingCarSimulation.Test
{
    [TestFixture]
    public class CarTests
    {
        [Test]
        public void Car_TurnLeft_ShouldChangeDirection()
        {
            var car = new Car("A", 1, 1, Direction.N);
            car.ExecuteCommand('L', 10, 10);
            Assert.AreEqual(Direction.W, car.Facing);
        }

        [Test]
        public void Car_TurnRight_ShouldChangeDirection()
        {
            var car = new Car("A", 1, 1, Direction.N);
            car.ExecuteCommand('R', 10, 10);
            Assert.AreEqual(Direction.E, car.Facing);
        }

        [Test]
        public void Car_MoveForward_ShouldIncreaseY_WhenFacingNorth()
        {
            var car = new Car("A", 1, 1, Direction.N);
            car.ExecuteCommand('F', 10, 10);
            Assert.AreEqual(2, car.Y);
        }

        [Test]
        public void Car_MoveForward_ShouldNotMoveBeyondBoundary()
        {
            var car = new Car("A", 0, 0, Direction.S);
            car.ExecuteCommand('F', 10, 10);
            Assert.AreEqual(0, car.Y);
        }
    }
}