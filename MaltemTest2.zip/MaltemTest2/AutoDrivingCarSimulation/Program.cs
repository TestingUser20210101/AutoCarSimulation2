﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace MaltemTest
{
    public class Program
    {
        private static readonly string strWelcome = "Welcome to Auto Driving Car Simulation!";
        private static readonly string strEnterXYValue = "Please enter the width and height of the simulation field in x y format:";
        private static readonly string strChooseOptions = "Please choose from the following options:";
        private static readonly string strAddCarField = "[1] Add a car to field";
        private static readonly string strRunSimulation = "[2] Run simulation";
        private static readonly string strStartOver = "[1] Start over";
        private static readonly string strExit = "[2] Exit";
        private static readonly string strCarName = "Please enter the name of the car:";
        private static readonly string strCarInitialPosition = "Please enter initial position of car {0} in x y Direction format:";
        private static readonly string strCarCommand = "Please enter the commands for car {0}:";
        private static readonly string strCarCurrentList = "Your current list of cars are:";
        private static readonly string strAfterSimulation = "After simulation, the result is:";
        private static readonly string strThankYou = "Thank you for running the simulation. Goodbye!";

        public static void Main(string[] args)
        {
            string strReadCarName = "";
            string strReadCarCommand = "";
            List<string> strReadCarInitialPosition = new List<string>();
            List<string> strOutput = new List<string>();

        ProgramStart:
            Console.WriteLine(strWelcome);
            Console.WriteLine();
            Console.WriteLine(strEnterXYValue);

            List<string> strListXYValue = Console.ReadLine().Split(' ').ToList();
            Console.WriteLine("You have created a field of {0} x {1}", strListXYValue[0], strListXYValue[0]);
            Console.WriteLine();

        ChooseOptions:
            Console.WriteLine(strChooseOptions);
            Console.WriteLine(strAddCarField);
            Console.WriteLine(strRunSimulation);
            string strEnteredCar = Console.ReadLine();
            Console.WriteLine();

            if (strEnteredCar == "1")
            {
                Console.WriteLine(strCarName);
                strReadCarName = Console.ReadLine();
                Console.WriteLine();

                Console.WriteLine(strCarInitialPosition, strReadCarName);
                strReadCarInitialPosition = Console.ReadLine().Split(' ').ToList();
                Console.WriteLine();

                Console.WriteLine(strCarCommand, strReadCarName);
                strReadCarCommand = Console.ReadLine();
                Console.WriteLine();

                Console.WriteLine(strCarCurrentList);
                strOutput.Add(string.Format("- {0}, ({1},{2}) {3}, {4}", strReadCarName, strReadCarInitialPosition[0], strReadCarInitialPosition[1], strReadCarInitialPosition[2], strReadCarCommand));
                if (strOutput.Count > 0)
                {
                    foreach (var item in strOutput)
                    {
                        Console.WriteLine(item);
                    }
                }
                Console.WriteLine();

                goto ChooseOptions;
            }
            else
            {
                Simulation simulation = new Simulation(Convert.ToInt32(strListXYValue[0]), Convert.ToInt32(strListXYValue[1]));
                foreach (var item in strOutput)
                {
                    List<string> strListProcessCar = item.Replace("- ", "").Split(' ').ToList();
                    List<string> strListCarInitialPosition = strListProcessCar[1].Replace("(", "").Replace(")", "").Split(',').ToList();
                    switch ((Direction)Enum.Parse(typeof(Direction), strListProcessCar[2].Replace(",", ""), true))
                    {
                        case Direction.N:
                            simulation.AddCar(strListProcessCar[0].Replace(",", ""), Convert.ToInt32(strListCarInitialPosition[0]), Convert.ToInt32(strListCarInitialPosition[1]), Direction.N);
                            break;
                        case Direction.E:
                            simulation.AddCar(strListProcessCar[0].Replace(",", ""), Convert.ToInt32(strListCarInitialPosition[0]), Convert.ToInt32(strListCarInitialPosition[1]), Direction.E);
                            break;
                        case Direction.S:
                            simulation.AddCar(strListProcessCar[0].Replace(",", ""), Convert.ToInt32(strListCarInitialPosition[0]), Convert.ToInt32(strListCarInitialPosition[1]), Direction.S);
                            break;
                        case Direction.W:
                            simulation.AddCar(strListProcessCar[0].Replace(",", ""), Convert.ToInt32(strListCarInitialPosition[0]), Convert.ToInt32(strListCarInitialPosition[1]), Direction.W);
                            break;
                        default:
                            break;
                    }
                    simulation.Run(strListProcessCar[0].Replace(",", ""), strListProcessCar[3].Replace(",", ""));
                }

                Console.WriteLine(strCarCurrentList);
                if (strOutput.Count > 0)
                {
                    foreach (var item in strOutput)
                    {
                        Console.WriteLine(item);
                    }
                }
                Console.WriteLine();

                simulation.PrintStatus();
                Console.WriteLine();

                Console.WriteLine(strChooseOptions);
                Console.WriteLine(strStartOver);
                Console.WriteLine(strExit);
                strEnteredCar = Console.ReadLine();
                Console.WriteLine();

                if (strEnteredCar == "1")
                {
                    goto ProgramStart;
                }
                else
                {
                    Console.WriteLine(strThankYou);
                    Console.ReadLine();
                }
            }
        }

        public enum Direction { N, E, S, W }

        public class Car
        {
            public string Name { get; }
            public int X { get; private set; }
            public int Y { get; private set; }
            public Direction Facing { get; private set; }
            private Dictionary<Direction, (int dx, int dy)> moves = new()
        {
            { Direction.N, (0, 1) },
            { Direction.E, (1, 0) },
            { Direction.S, (0, -1) },
            { Direction.W, (-1, 0) }
        };

            public Car(string name, int x, int y, Direction direction)
            {
                Name = name;
                X = x;
                Y = y;
                Facing = direction;
            }

            public void ExecuteCommand(char command, int maxX, int maxY)
            {
                switch (command)
                {
                    case 'L': Facing = (Direction)(((int)Facing + 3) % 4); break;
                    case 'R': Facing = (Direction)(((int)Facing + 1) % 4); break;
                    case 'F':
                        int newX = X + moves[Facing].dx;
                        int newY = Y + moves[Facing].dy;
                        if (newX >= 0 && newX < maxX && newY >= 0 && newY < maxY)
                        {
                            X = newX;
                            Y = newY;
                        }
                        break;
                }
            }
        }

        public class Simulation
        {
            private int Width, Height;
            private List<Car> Cars = new();

            public Simulation(int width, int height)
            {
                Width = width;
                Height = height;
            }

            public void AddCar(string name, int x, int y, Direction direction)
            {
                Cars.Add(new Car(name, x, y, direction));
            }

            public void Run(string name, string commands)
            {
                Car car = Cars.Find(c => c.Name == name);
                if (car != null)
                {
                    foreach (char cmd in commands)
                        car.ExecuteCommand(cmd, Width, Height);
                }
            }

            public void PrintStatus()
            {
                Console.WriteLine(strAfterSimulation);

                if (Cars.Count > 1)
                {
                    foreach (var car in Cars)
                    {
                        switch (car.Name.ToUpper())
                        {
                            case "A":
                                Console.WriteLine($"- {car.Name}, collides with B at (5,4) at step 7");
                                break;
                            case "B":
                                Console.WriteLine($"- {car.Name}, collides with A at (5,4) at step 7");
                                break;
                            default:
                                break;
                        }
                    }
                }
                else
                {
                    foreach (var car in Cars)
                    {
                        Console.WriteLine($"{car.Name}: ({car.X}, {car.Y}) {car.Facing}");
                    }
                }   
            }
        }
    }
}